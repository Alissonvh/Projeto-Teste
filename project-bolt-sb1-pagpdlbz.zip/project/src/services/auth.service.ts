import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
import { LoginInput, RegisterInput } from '../schemas/auth.schema';
import { AppError } from '../utils/app-error';
import { UserService } from './user.service';
import { TokenService } from './token.service';

export class AuthService {
  private prisma: PrismaClient;
  private userService: UserService;
  private tokenService: TokenService;

  constructor() {
    this.prisma = new PrismaClient();
    this.userService = new UserService();
    this.tokenService = new TokenService();
  }

  async register(userData: RegisterInput) {
    // Check if user already exists
    const existingUser = await this.prisma.user.findUnique({
      where: { email: userData.email }
    });

    if (existingUser) {
      throw new AppError('Email already in use', 409);
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(userData.password, 10);

    // Create user
    const user = await this.prisma.user.create({
      data: {
        name: userData.name,
        email: userData.email,
        password: hashedPassword
      }
    });

    // Return user without password
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }

  async login(credentials: LoginInput) {
    // Find user by email
    const user = await this.prisma.user.findUnique({
      where: { email: credentials.email }
    });

    if (!user) {
      throw new AppError('Invalid credentials', 401);
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(credentials.password, user.password);

    if (!isPasswordValid) {
      throw new AppError('Invalid credentials', 401);
    }

    // Generate tokens
    const accessToken = this.tokenService.generateAccessToken(user.id);
    const refreshToken = await this.tokenService.generateRefreshToken(user.id);

    // Return user and tokens
    const { password, ...userWithoutPassword } = user;
    return {
      user: userWithoutPassword,
      accessToken,
      refreshToken
    };
  }

  async refreshToken(token: string) {
    try {
      // Verify refresh token
      const payload = await this.tokenService.verifyRefreshToken(token);
      
      // Generate new tokens
      const accessToken = this.tokenService.generateAccessToken(payload.userId);
      const refreshToken = await this.tokenService.generateRefreshToken(payload.userId, token);
      
      return { accessToken, refreshToken };
    } catch (error) {
      throw new AppError('Invalid refresh token', 401);
    }
  }

  async logout(token: string) {
    try {
      // Delete refresh token
      await this.tokenService.revokeRefreshToken(token);
      return true;
    } catch (error) {
      throw new AppError('Invalid refresh token', 401);
    }
  }
}